@extends('layouts.app')
@section('content')
    <div class="min-vh-100 d-flex flex-column 
                justify-content-between">
        <div class="container" style="margin-top:10%;color:white">
            <div class="card">
                <div class="card-body">
                    <blockquote class="blockquote">
                        <p>We are a third year computer science students that are making a PHP project using Laravel
                            framework,
                            which is a back-end framework.</p>
                        <footer class="card-blockquote">Our university is the Lebanese University Faculty of Sciences<cite
                                title="Source title">
                                <hr> Amir el-Halabi...
                                <hr>Yousef Ahmad...
                                <hr> Alaa Nasr...
                            </cite></footer>
                    </blockquote>
                </div>
            </div>
        </div>
    @endsection
